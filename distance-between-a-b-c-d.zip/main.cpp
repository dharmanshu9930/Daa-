/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <math.h>


using namespace std;

int main()
{
    int a,b,c,d;
    cout<<"ENTER (a,b) , (c,d) :\n " ;
    cin>>a>>b>>c>>d;
    cout<<"DISTANCE BETWEEN (a,b) and (c,d) is : " << sqrt(pow(d-b,2)+pow(c-a,2))<< " units ";
    
    return 0;
}